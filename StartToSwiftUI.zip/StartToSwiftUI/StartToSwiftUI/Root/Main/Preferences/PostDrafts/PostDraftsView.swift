//
//  PostDraftsView.swift
//  StartToSwiftUI
//
//  Created by Andrey Efimov on 13.11.2025.
//

import SwiftUI

struct PostDraftsView: View {
    
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var vm: PostsViewModel
    
    private let hapticManager = HapticService.shared
    
    @State private var selectedPost: Post?
    @State private var selectedPostToDelete: Post?
        
    // MARK: VIEW BODY
    
    var body: some View {
        ZStack (alignment: .bottomTrailing) {
            
            if vm.allPosts.filter({ $0.draft == true }).isEmpty {
                postDraftsIsEmpty
            } else {
                    List {
                        ForEach(vm.allPosts.filter { $0.draft == true }) { post in
                            PostDraftsRowView(post: post)
                                .onTapGesture {
                                    selectedPost = post
                                }
                                .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                                    Button("Delete", systemImage: "trash") {
                                        selectedPostToDelete = post
                                        withAnimation {
                                            vm.deletePost(post: selectedPostToDelete ?? nil)
                                            hapticManager.notification(type: .success)
                                        }
                                    }.tint(Color.mycolor.myRed)
                                }
                        }
                    } // List
                    .navigationTitle("Post drafts")
                    .navigationBarBackButtonHidden(true)
                    .toolbarBackground(.ultraThinMaterial, for: .navigationBar)
                    .toolbar {
                        ToolbarItem(placement: .navigationBarLeading) {
                            CircleStrokeButtonView(
                                iconName: "chevron.left",
                                isShownCircle: false
                            ) {
                                dismiss()
                            }
                        }
                    }
            }
        }
        .fullScreenCover(item: $selectedPost) { selectedPostToEdit in
            AddEditPostSheet(post: selectedPostToEdit)
        } // ForEach

    }
    
    private var postDraftsIsEmpty: some View {
        ContentUnavailableView(
            "No Post Drafts",
            systemImage: "square.stack.3d.up",
            description: Text("Post drafts will appear here when you save drafts.")
        )
    }
    
}

#Preview {
    NavigationStack {
        PostDraftsView()
            .environmentObject(PostsViewModel())
    }
}
