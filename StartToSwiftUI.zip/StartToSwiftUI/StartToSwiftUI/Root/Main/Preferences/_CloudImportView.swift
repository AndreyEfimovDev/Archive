//
//  CloudImportView.swift
//  StartToSwiftUI
//
//  Created by Andrey Efimov on 22.10.2025.
//

import SwiftUI

struct CloudImportView: View {
    
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var vm: PostsViewModel
    
    private let hapticManager = HapticManager.shared
    
    private let selectedURL = Constants.cloudPostsURL
    
    @State private var isLoading: Bool = false
    @State private var isLoaded: Bool = false
    @State private var postCount: Int = 0
    
    var body: some View {
        VStack {
            textSection
                .managingPostsTextFormater()
            
            CapsuleButtonView(
                primaryTitle: "Import Posts",
                secondaryTitle: "\(postCount) Posts Imported",
                isToChangeTitile: isLoaded) {
                    isLoaded.toggle()
                    importFromCloud()
                }
                .onChange(of: vm.allPosts.count) { oldValue, newValue in
                    postCount = newValue - oldValue
                }
                .disabled(isLoaded)
                .padding(.top, 30)
            
            Spacer()
            
            if isLoading {
                ProgressView("Importing posts...")
                    .padding()
                    .background(.regularMaterial)
                    .cornerRadius(10)
            }
        }
        .padding(.horizontal, 30)
        .padding(.top, 30)
        .padding(30)
        .alert("Import Error", isPresented: $vm.showCloudImportAlert) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(vm.cloudImportError ?? "Unknown error")
        }
    }
    
    private var textSection: some View {
        Text("""
            You are about to import pre-loaded posts from the cloud.
                       
            The pre-loaded posts will append all current posts in the App, excluding duplicates by post title.
            
            """)
    }
    
    private func importFromCloud() {
        
        isLoading = true
        vm.importPostsFromCloud(urlString: selectedURL) {
            isLoading = false
//            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
//                dismiss()
//            }
        }
    }
    
    private func checkForUpdates() {
        vm.checkCloudForUpdates { hasUpdates in
            if hasUpdates {
                // Можно показать alert с предложением обновиться
                print("Updates available!")
            } else {
                print("No updates available")
            }
        }
    }
}

#Preview {
    CloudImportView()
        .environmentObject(PostsViewModel())
}
