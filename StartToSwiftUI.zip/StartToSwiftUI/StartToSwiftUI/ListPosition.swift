//
//  ListPosition.swift
//  StartToSwiftUI
//
//  Created by Andrey Efimov on 30.08.2025.
//

import SwiftUI

struct ScrollToTopListView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    ScrollToTopListView()
}
