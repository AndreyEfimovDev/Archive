//
//  My1stApp-BBC
//
//  Created by Andrey Efimov on 03.05.2024.
//
//
//import SwiftUI
//import SafariServices
//
//struct SafariWebService: UIViewControllerRepresentable {
//    
//    let url: URL
//    
//    func makeUIViewController(context: UIViewControllerRepresentableContext<SafariWebService>) -> SFSafariViewController {
//        SFSafariViewController(url: url)
//    }
//    
//    func updateUIViewController(_ uiViewController: SFSafariViewController, context: UIViewControllerRepresentableContext<SafariWebService>) {}
//}
